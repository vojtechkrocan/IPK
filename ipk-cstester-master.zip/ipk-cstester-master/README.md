Client <=> Server Aplication Tester 2015
========================================

./cstester port-number

Example:
-----------
chmod +x cstester.sh

./cstester 4444
